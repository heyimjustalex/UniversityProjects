import { createContext, useState, useEffect } from "react";
import { jwtDecode } from "jwt-decode";

export const AuthContext = createContext({
  name: null,
  token: null,
  role: null,
  userId: null,
  login: (token) => {},
  logout: () => {},
});

export const AuthContextProvider = (props) => {
  const logoutSetLocalStorage = () => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("userId");
      localStorage.removeItem("name");
      localStorage.removeItem("role");
      localStorage.removeItem("token");
    }
  };

  const retrieveStoredToken = () => {
    let storedUserId;
    let storedName;
    let storedRole;
    let storedToken;
    if (typeof window !== "undefined") {
      storedUserId = localStorage.getItem("userId");
      storedName = localStorage.getItem("name");
      storedRole = localStorage.getItem("role");
      storedToken = localStorage.getItem("token");
    }

    return {
      token: storedToken,
      role: storedRole,
      userId: storedUserId,
      name: storedName,
    };
  };

  const retrievedToken = retrieveStoredToken();
  let initialToken;
  let initialRole;
  let initialName;
  let initialUserId;

  if (retrievedToken) {
    initialToken = retrievedToken.token;
    initialRole = retrievedToken.role;
    initialName = retrievedToken.name;
    initialUserId = retrievedToken.userId;
  }

  const [name, setName] = useState(initialName);
  const [token, setToken] = useState(initialToken);
  const [role, setRole] = useState(initialRole);
  const [userId, setUserId] = useState(initialUserId);

  const logoutSetStates = () => {
    setName(null);
    setRole(null);
    setUserId(null);
    setToken(null);
  };

  const logout = () => {
    logoutSetLocalStorage();
    logoutSetStates();
  };

  const loginSetStates = (token) => {
    const { Name, Role, UserId, exp } = jwtDecode(token);
    setName(Name);
    setRole(Role);
    setUserId(UserId);
    setToken(token);
  };

  const loginSetLocalStorage = (token) => {
    const { Name, Role, UserId } = jwtDecode(token);
    if (typeof window !== "undefined") {
      localStorage.setItem("userId", UserId);
      localStorage.setItem("name", Name);
      localStorage.setItem("role", Role);
      localStorage.setItem("token", token);
    }
  };

  const login = (token) => {
    loginSetLocalStorage(token);
    loginSetStates(token);
  };

  const ContextValue = {
    name: name,
    userId: userId,
    token: token,
    role: role,
    login: login,
    logout: logout,
  };

  return (
    <AuthContext.Provider value={ContextValue}>
      {props.children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
