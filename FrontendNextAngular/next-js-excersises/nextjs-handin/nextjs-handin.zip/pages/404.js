export default function NotFoundPage() {
  return (
    <div>
      <h1>Not found</h1>
    </div>
  );
}
