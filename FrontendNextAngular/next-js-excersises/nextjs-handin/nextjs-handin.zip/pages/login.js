import LoginForm from "@/components/login/LoginForm";
import ErrorMessage from "@/components/ui/ErrorMessage";
import Layout from "@/components/ui/Layout";
import LoadingRing from "@/components/ui/LoadingRing";
import { loginUserAPI } from "@/lib/api";
import AuthContext from "@/store/AuthContext";
import { useContext } from "react";

export default function LoginPage() {
  const { postData, response, loading, error } = loginUserAPI();
  const authCTX = useContext(AuthContext);

  const handleLogin = async (email, password) => {
    try {
      await postData(email, password);
      console.log(response);
      if (response.status === 200) {
        // Successful login, handle accordingly
        authCTX.login(response.data.jwt);
        console.log("Login successful:", response.data);
      }
    } catch (error) {
      // Handle errors
      console.error("Login failed:", error.message);
    }
  };

  return (
    <Layout>
      {!loading && (
        <LoginForm
          submitDisabledButton={loading}
          onFormSubmit={handleLogin}
          buttonTitle="Login"
        ></LoginForm>
      )}

      {loading && <LoadingRing />}
      {error && <ErrorMessage message={error.message} />}
    </Layout>
  );
}
