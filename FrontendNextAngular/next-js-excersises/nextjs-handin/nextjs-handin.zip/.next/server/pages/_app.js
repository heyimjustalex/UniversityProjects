/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _store_AuthContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/store/AuthContext */ \"./store/AuthContext.js\");\n/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../globals.css */ \"./globals.css\");\n/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_globals_css__WEBPACK_IMPORTED_MODULE_2__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_AuthContext__WEBPACK_IMPORTED_MODULE_1__]);\n_store_AuthContext__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nfunction MyApp({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_store_AuthContext__WEBPACK_IMPORTED_MODULE_1__.AuthContextProvider, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\alex\\\\Desktop\\\\next\\\\nextjs-handin\\\\pages\\\\_app.js\",\n            lineNumber: 7,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\alex\\\\Desktop\\\\next\\\\nextjs-handin\\\\pages\\\\_app.js\",\n        lineNumber: 6,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBMEQ7QUFDbEM7QUFFeEIsU0FBU0MsTUFBTSxFQUFFQyxTQUFTLEVBQUVDLFNBQVMsRUFBRTtJQUNyQyxxQkFDRSw4REFBQ0gsbUVBQW1CQTtrQkFDbEIsNEVBQUNFO1lBQVcsR0FBR0MsU0FBUzs7Ozs7Ozs7Ozs7QUFHOUI7QUFFQSxpRUFBZUYsS0FBS0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25leHRqcy1oYW5kaW4vLi9wYWdlcy9fYXBwLmpzP2UwYWQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXV0aENvbnRleHRQcm92aWRlciB9IGZyb20gXCJAL3N0b3JlL0F1dGhDb250ZXh0XCI7XHJcbmltcG9ydCBcIi4uL2dsb2JhbHMuY3NzXCI7XHJcblxyXG5mdW5jdGlvbiBNeUFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPEF1dGhDb250ZXh0UHJvdmlkZXI+XHJcbiAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cclxuICAgIDwvQXV0aENvbnRleHRQcm92aWRlcj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBNeUFwcDtcclxuIl0sIm5hbWVzIjpbIkF1dGhDb250ZXh0UHJvdmlkZXIiLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./store/AuthContext.js":
/*!******************************!*\
  !*** ./store/AuthContext.js ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   AuthContext: () => (/* binding */ AuthContext),\n/* harmony export */   AuthContextProvider: () => (/* binding */ AuthContextProvider),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jwt-decode */ \"jwt-decode\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jwt_decode__WEBPACK_IMPORTED_MODULE_2__]);\njwt_decode__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nconst AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({\n    name: null,\n    token: null,\n    role: null,\n    userId: null,\n    login: (token)=>{},\n    logout: ()=>{}\n});\nconst AuthContextProvider = (props)=>{\n    const logoutSetLocalStorage = ()=>{\n        if (false) {}\n    };\n    const retrieveStoredToken = ()=>{\n        let storedUserId;\n        let storedName;\n        let storedRole;\n        let storedToken;\n        if (false) {}\n        return {\n            token: storedToken,\n            role: storedRole,\n            userId: storedUserId,\n            name: storedName\n        };\n    };\n    const retrievedToken = retrieveStoredToken();\n    let initialToken;\n    let initialRole;\n    let initialName;\n    let initialUserId;\n    if (retrievedToken) {\n        initialToken = retrievedToken.token;\n        initialRole = retrievedToken.role;\n        initialName = retrievedToken.name;\n        initialUserId = retrievedToken.userId;\n    }\n    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialName);\n    const [token, setToken] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialToken);\n    const [role, setRole] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialRole);\n    const [userId, setUserId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialUserId);\n    const logoutSetStates = ()=>{\n        setName(null);\n        setRole(null);\n        setUserId(null);\n        setToken(null);\n    };\n    const logout = ()=>{\n        logoutSetLocalStorage();\n        logoutSetStates();\n    };\n    const loginSetStates = (token)=>{\n        const { Name, Role, UserId, exp } = (0,jwt_decode__WEBPACK_IMPORTED_MODULE_2__.jwtDecode)(token);\n        setName(Name);\n        setRole(Role);\n        setUserId(UserId);\n        setToken(token);\n    };\n    const loginSetLocalStorage = (token)=>{\n        const { Name, Role, UserId } = (0,jwt_decode__WEBPACK_IMPORTED_MODULE_2__.jwtDecode)(token);\n        if (false) {}\n    };\n    const login = (token)=>{\n        loginSetLocalStorage(token);\n        loginSetStates(token);\n    };\n    const ContextValue = {\n        name: name,\n        userId: userId,\n        token: token,\n        role: role,\n        login: login,\n        logout: logout\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(AuthContext.Provider, {\n        value: ContextValue,\n        children: props.children\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\alex\\\\Desktop\\\\next\\\\nextjs-handin\\\\store\\\\AuthContext.js\",\n        lineNumber: 106,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthContext);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS9BdXRoQ29udGV4dC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBMkQ7QUFDcEI7QUFFaEMsTUFBTUksNEJBQWNKLG9EQUFhQSxDQUFDO0lBQ3ZDSyxNQUFNO0lBQ05DLE9BQU87SUFDUEMsTUFBTTtJQUNOQyxRQUFRO0lBQ1JDLE9BQU8sQ0FBQ0gsU0FBVztJQUNuQkksUUFBUSxLQUFPO0FBQ2pCLEdBQUc7QUFFSSxNQUFNQyxzQkFBc0IsQ0FBQ0M7SUFDbEMsTUFBTUMsd0JBQXdCO1FBQzVCLElBQUksS0FBNkIsRUFBRSxFQUtsQztJQUNIO0lBRUEsTUFBTUcsc0JBQXNCO1FBQzFCLElBQUlDO1FBQ0osSUFBSUM7UUFDSixJQUFJQztRQUNKLElBQUlDO1FBQ0osSUFBSSxLQUE2QixFQUFFLEVBS2xDO1FBRUQsT0FBTztZQUNMZCxPQUFPYztZQUNQYixNQUFNWTtZQUNOWCxRQUFRUztZQUNSWixNQUFNYTtRQUNSO0lBQ0Y7SUFFQSxNQUFNSSxpQkFBaUJOO0lBQ3ZCLElBQUlPO0lBQ0osSUFBSUM7SUFDSixJQUFJQztJQUNKLElBQUlDO0lBRUosSUFBSUosZ0JBQWdCO1FBQ2xCQyxlQUFlRCxlQUFlaEIsS0FBSztRQUNuQ2tCLGNBQWNGLGVBQWVmLElBQUk7UUFDakNrQixjQUFjSCxlQUFlakIsSUFBSTtRQUNqQ3FCLGdCQUFnQkosZUFBZWQsTUFBTTtJQUN2QztJQUVBLE1BQU0sQ0FBQ0gsTUFBTXNCLFFBQVEsR0FBRzFCLCtDQUFRQSxDQUFDd0I7SUFDakMsTUFBTSxDQUFDbkIsT0FBT3NCLFNBQVMsR0FBRzNCLCtDQUFRQSxDQUFDc0I7SUFDbkMsTUFBTSxDQUFDaEIsTUFBTXNCLFFBQVEsR0FBRzVCLCtDQUFRQSxDQUFDdUI7SUFDakMsTUFBTSxDQUFDaEIsUUFBUXNCLFVBQVUsR0FBRzdCLCtDQUFRQSxDQUFDeUI7SUFFckMsTUFBTUssa0JBQWtCO1FBQ3RCSixRQUFRO1FBQ1JFLFFBQVE7UUFDUkMsVUFBVTtRQUNWRixTQUFTO0lBQ1g7SUFFQSxNQUFNbEIsU0FBUztRQUNiRztRQUNBa0I7SUFDRjtJQUVBLE1BQU1DLGlCQUFpQixDQUFDMUI7UUFDdEIsTUFBTSxFQUFFMkIsSUFBSSxFQUFFQyxJQUFJLEVBQUVDLE1BQU0sRUFBRUMsR0FBRyxFQUFFLEdBQUdqQyxxREFBU0EsQ0FBQ0c7UUFDOUNxQixRQUFRTTtRQUNSSixRQUFRSztRQUNSSixVQUFVSztRQUNWUCxTQUFTdEI7SUFDWDtJQUVBLE1BQU0rQix1QkFBdUIsQ0FBQy9CO1FBQzVCLE1BQU0sRUFBRTJCLElBQUksRUFBRUMsSUFBSSxFQUFFQyxNQUFNLEVBQUUsR0FBR2hDLHFEQUFTQSxDQUFDRztRQUN6QyxJQUFJLEtBQTZCLEVBQUUsRUFLbEM7SUFDSDtJQUVBLE1BQU1HLFFBQVEsQ0FBQ0g7UUFDYitCLHFCQUFxQi9CO1FBQ3JCMEIsZUFBZTFCO0lBQ2pCO0lBRUEsTUFBTWlDLGVBQWU7UUFDbkJsQyxNQUFNQTtRQUNORyxRQUFRQTtRQUNSRixPQUFPQTtRQUNQQyxNQUFNQTtRQUNORSxPQUFPQTtRQUNQQyxRQUFRQTtJQUNWO0lBRUEscUJBQ0UsOERBQUNOLFlBQVlvQyxRQUFRO1FBQUNDLE9BQU9GO2tCQUMxQjNCLE1BQU04QixRQUFROzs7Ozs7QUFHckIsRUFBRTtBQUVGLGlFQUFldEMsV0FBV0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25leHRqcy1oYW5kaW4vLi9zdG9yZS9BdXRoQ29udGV4dC5qcz8xN2Q0Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgand0RGVjb2RlIH0gZnJvbSBcImp3dC1kZWNvZGVcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBBdXRoQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoe1xyXG4gIG5hbWU6IG51bGwsXHJcbiAgdG9rZW46IG51bGwsXHJcbiAgcm9sZTogbnVsbCxcclxuICB1c2VySWQ6IG51bGwsXHJcbiAgbG9naW46ICh0b2tlbikgPT4ge30sXHJcbiAgbG9nb3V0OiAoKSA9PiB7fSxcclxufSk7XHJcblxyXG5leHBvcnQgY29uc3QgQXV0aENvbnRleHRQcm92aWRlciA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IGxvZ291dFNldExvY2FsU3RvcmFnZSA9ICgpID0+IHtcclxuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwidXNlcklkXCIpO1xyXG4gICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShcIm5hbWVcIik7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwicm9sZVwiKTtcclxuICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJ0b2tlblwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCByZXRyaWV2ZVN0b3JlZFRva2VuID0gKCkgPT4ge1xyXG4gICAgbGV0IHN0b3JlZFVzZXJJZDtcclxuICAgIGxldCBzdG9yZWROYW1lO1xyXG4gICAgbGV0IHN0b3JlZFJvbGU7XHJcbiAgICBsZXQgc3RvcmVkVG9rZW47XHJcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICBzdG9yZWRVc2VySWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJJZFwiKTtcclxuICAgICAgc3RvcmVkTmFtZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibmFtZVwiKTtcclxuICAgICAgc3RvcmVkUm9sZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwicm9sZVwiKTtcclxuICAgICAgc3RvcmVkVG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInRva2VuXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRva2VuOiBzdG9yZWRUb2tlbixcclxuICAgICAgcm9sZTogc3RvcmVkUm9sZSxcclxuICAgICAgdXNlcklkOiBzdG9yZWRVc2VySWQsXHJcbiAgICAgIG5hbWU6IHN0b3JlZE5hbWUsXHJcbiAgICB9O1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJldHJpZXZlZFRva2VuID0gcmV0cmlldmVTdG9yZWRUb2tlbigpO1xyXG4gIGxldCBpbml0aWFsVG9rZW47XHJcbiAgbGV0IGluaXRpYWxSb2xlO1xyXG4gIGxldCBpbml0aWFsTmFtZTtcclxuICBsZXQgaW5pdGlhbFVzZXJJZDtcclxuXHJcbiAgaWYgKHJldHJpZXZlZFRva2VuKSB7XHJcbiAgICBpbml0aWFsVG9rZW4gPSByZXRyaWV2ZWRUb2tlbi50b2tlbjtcclxuICAgIGluaXRpYWxSb2xlID0gcmV0cmlldmVkVG9rZW4ucm9sZTtcclxuICAgIGluaXRpYWxOYW1lID0gcmV0cmlldmVkVG9rZW4ubmFtZTtcclxuICAgIGluaXRpYWxVc2VySWQgPSByZXRyaWV2ZWRUb2tlbi51c2VySWQ7XHJcbiAgfVxyXG5cclxuICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZShpbml0aWFsTmFtZSk7XHJcbiAgY29uc3QgW3Rva2VuLCBzZXRUb2tlbl0gPSB1c2VTdGF0ZShpbml0aWFsVG9rZW4pO1xyXG4gIGNvbnN0IFtyb2xlLCBzZXRSb2xlXSA9IHVzZVN0YXRlKGluaXRpYWxSb2xlKTtcclxuICBjb25zdCBbdXNlcklkLCBzZXRVc2VySWRdID0gdXNlU3RhdGUoaW5pdGlhbFVzZXJJZCk7XHJcblxyXG4gIGNvbnN0IGxvZ291dFNldFN0YXRlcyA9ICgpID0+IHtcclxuICAgIHNldE5hbWUobnVsbCk7XHJcbiAgICBzZXRSb2xlKG51bGwpO1xyXG4gICAgc2V0VXNlcklkKG51bGwpO1xyXG4gICAgc2V0VG9rZW4obnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgbG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgbG9nb3V0U2V0TG9jYWxTdG9yYWdlKCk7XHJcbiAgICBsb2dvdXRTZXRTdGF0ZXMoKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBsb2dpblNldFN0YXRlcyA9ICh0b2tlbikgPT4ge1xyXG4gICAgY29uc3QgeyBOYW1lLCBSb2xlLCBVc2VySWQsIGV4cCB9ID0gand0RGVjb2RlKHRva2VuKTtcclxuICAgIHNldE5hbWUoTmFtZSk7XHJcbiAgICBzZXRSb2xlKFJvbGUpO1xyXG4gICAgc2V0VXNlcklkKFVzZXJJZCk7XHJcbiAgICBzZXRUb2tlbih0b2tlbik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgbG9naW5TZXRMb2NhbFN0b3JhZ2UgPSAodG9rZW4pID0+IHtcclxuICAgIGNvbnN0IHsgTmFtZSwgUm9sZSwgVXNlcklkIH0gPSBqd3REZWNvZGUodG9rZW4pO1xyXG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJ1c2VySWRcIiwgVXNlcklkKTtcclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJuYW1lXCIsIE5hbWUpO1xyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInJvbGVcIiwgUm9sZSk7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwidG9rZW5cIiwgdG9rZW4pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGxvZ2luID0gKHRva2VuKSA9PiB7XHJcbiAgICBsb2dpblNldExvY2FsU3RvcmFnZSh0b2tlbik7XHJcbiAgICBsb2dpblNldFN0YXRlcyh0b2tlbik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgQ29udGV4dFZhbHVlID0ge1xyXG4gICAgbmFtZTogbmFtZSxcclxuICAgIHVzZXJJZDogdXNlcklkLFxyXG4gICAgdG9rZW46IHRva2VuLFxyXG4gICAgcm9sZTogcm9sZSxcclxuICAgIGxvZ2luOiBsb2dpbixcclxuICAgIGxvZ291dDogbG9nb3V0LFxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8QXV0aENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e0NvbnRleHRWYWx1ZX0+XHJcbiAgICAgIHtwcm9wcy5jaGlsZHJlbn1cclxuICAgIDwvQXV0aENvbnRleHQuUHJvdmlkZXI+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEF1dGhDb250ZXh0O1xyXG4iXSwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZVN0YXRlIiwidXNlRWZmZWN0Iiwiand0RGVjb2RlIiwiQXV0aENvbnRleHQiLCJuYW1lIiwidG9rZW4iLCJyb2xlIiwidXNlcklkIiwibG9naW4iLCJsb2dvdXQiLCJBdXRoQ29udGV4dFByb3ZpZGVyIiwicHJvcHMiLCJsb2dvdXRTZXRMb2NhbFN0b3JhZ2UiLCJsb2NhbFN0b3JhZ2UiLCJyZW1vdmVJdGVtIiwicmV0cmlldmVTdG9yZWRUb2tlbiIsInN0b3JlZFVzZXJJZCIsInN0b3JlZE5hbWUiLCJzdG9yZWRSb2xlIiwic3RvcmVkVG9rZW4iLCJnZXRJdGVtIiwicmV0cmlldmVkVG9rZW4iLCJpbml0aWFsVG9rZW4iLCJpbml0aWFsUm9sZSIsImluaXRpYWxOYW1lIiwiaW5pdGlhbFVzZXJJZCIsInNldE5hbWUiLCJzZXRUb2tlbiIsInNldFJvbGUiLCJzZXRVc2VySWQiLCJsb2dvdXRTZXRTdGF0ZXMiLCJsb2dpblNldFN0YXRlcyIsIk5hbWUiLCJSb2xlIiwiVXNlcklkIiwiZXhwIiwibG9naW5TZXRMb2NhbFN0b3JhZ2UiLCJzZXRJdGVtIiwiQ29udGV4dFZhbHVlIiwiUHJvdmlkZXIiLCJ2YWx1ZSIsImNoaWxkcmVuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./store/AuthContext.js\n");

/***/ }),

/***/ "./globals.css":
/*!*********************!*\
  !*** ./globals.css ***!
  \*********************/
/***/ (() => {



/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "jwt-decode":
/*!*****************************!*\
  !*** external "jwt-decode" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = import("jwt-decode");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();